package org.stone.beecp.example.keyDs;

import org.stone.beecp.RawConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;

public class KeyConnectionFactory implements RawConnectionFactory {

    private KeyStore store;

    public KeyConnectionFactory(KeyStore store) {
        this.store = store;
    }

    public Connection create() throws SQLException {
        Object key = store.getLastKey();
        Connection con = null;//here,create your connection to db
        return new KeyConnection(key, con);
    }
}
