package org.stone.beecp.example.keyDs;

import java.sql.SQLException;

public class KeyExpiredException extends SQLException {
}
