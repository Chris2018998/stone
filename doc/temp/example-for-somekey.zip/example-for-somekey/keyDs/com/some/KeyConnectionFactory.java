package some;

import org.stone.beecp.RawConnectionFactory;

import java.sql.Connection;
import java.sql.SQLException;

public class KeyConnectionFactory implements RawConnectionFactory {

    private KeyStore store;

    public KeyConnectionFactory(KeyStore store) {
        this.store = store;
    }

    public Connection create() throws SQLException {
        String key = store.getNewKey();
        Connection con = null;//here,create your connection to db
        con.setClientInfo("MyKey", key);
        return con;
    }
}
