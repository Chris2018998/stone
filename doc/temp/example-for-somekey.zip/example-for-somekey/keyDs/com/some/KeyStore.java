package some;

public class KeyStore {
    private String newKey;
    private String oldKey;

    public synchronized boolean existsKey(String key) {
        return key == newKey || key == oldKey;
    }

    public synchronized String getNewKey() {//call in KeyConnectionFactory
        return this.newKey;
    }

    public synchronized void setNewKey(String newKey) {
        this.oldKey = this.newKey;
        this.newKey = newKey;
    }
}
