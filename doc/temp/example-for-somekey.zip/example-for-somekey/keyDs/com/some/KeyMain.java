package some;

import org.stone.beecp.BeeDataSource;
import org.stone.beecp.BeeDataSourceConfig;

public class KeyMain {
    public static void main(String[] args) {
        BeeDataSourceConfig config = new BeeDataSourceConfig();

        KeyStore store = new KeyStore();
        KeyConnectionFactory factory = new KeyConnectionFactory(store);
        config.setRawConnectionFactory(factory);
        BeeDataSource beeDs = new BeeDataSource(config);

        KeyDataSource ds = new KeyDataSource(store, beeDs);
    }
}
