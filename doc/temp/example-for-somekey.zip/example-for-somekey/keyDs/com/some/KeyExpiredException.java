package some;

import java.sql.SQLException;

public class KeyExpiredException extends SQLException {
}
