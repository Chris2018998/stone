package org.stone.beecp.example.keyDs;

import org.stone.beecp.BeeDataSource;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;

public class KeyDataSource extends DataSource {

    private KeyStore keys;

    private BeeDataSource ds;

    public KeyDataSource(KeyStore keys, BeeDataSource ds) {
        this.ds = ds;
        this.keys = keys;
    }

    public Connection getConnection() throws SQLException {
        Connection proxyConnection = ds.getConnection();

        Connection rawConnection = proxyConnection.raw;//@todo,get it by reflection

        KeyConnection keyConnection = (KeyConnection) rawConnection;//cast it to KeyConnection

        Object key = keyConnection.getKey();

        if (keys.existsKey(key)) {//not expired,return result
            return proxyConnection;
        } else {
            proxyConnection.close();
            throw new KeyExpiredException();
        }
    }

    public Connection getConnection(String username, String password) throws SQLException {
        throw new SQLFeatureNotSupportedException("Not support");
    }

    public final PrintWriter getLogWriter() throws SQLException {
        throw new SQLFeatureNotSupportedException("Not supported");
    }

    public final void setLogWriter(PrintWriter out) throws SQLException {
        throw new SQLFeatureNotSupportedException("Not supported");
    }

    public int getLoginTimeout() throws SQLException {
        throw new SQLFeatureNotSupportedException("Not supported");
    }

    public final void setLoginTimeout(int seconds) throws SQLException {
        throw new SQLFeatureNotSupportedException("Not supported");
    }

    public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException {
        throw new SQLFeatureNotSupportedException("Not supported");
    }
}
