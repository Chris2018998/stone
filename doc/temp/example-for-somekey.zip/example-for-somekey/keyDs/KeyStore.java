package org.stone.beecp.example.keyDs;

public class KeyStore {
    private Object newKey;
    private Object oldKey;

    public synchronized boolean existsKey(Object key) {//call in KeyDataSource
        return key == newKey || key == oldKey;
    }

    public synchronized void putKey(Object newKey) {
        this.oldKey = this.newKey;
        this.newKey = newKey;
    }

    public synchronized Object getLastKey() {//call in KeyConnectionFactory
        return this.newKey;
    }
}
