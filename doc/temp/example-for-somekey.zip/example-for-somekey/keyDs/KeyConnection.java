package org.stone.beecp.example.keyDs;

import java.sql.Connection;

public class KeyConnection implements Connection {

    private Object key;

    private Connection connection;

    public KeyConnection(Object key, Connection connection) {
        this.key = key;
        this.connection = connection;
    }

    public Object getKey() {
        return key;
    }

    /******************************************@todo,other override methods are below**********************************/

}
