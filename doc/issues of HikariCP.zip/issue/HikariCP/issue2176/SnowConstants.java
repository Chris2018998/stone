package org.stone.beecp.issue.HikariCP.issue2176;

public class SnowConstants {

    public static final String Snow_Key = "SnowKey";

}
