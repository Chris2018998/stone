package org.stone.beecp.issue.HikariCP.issue2176;

import java.sql.SQLException;

public class KeyExpiredException extends SQLException {
}
