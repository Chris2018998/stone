package org.stone.beecp.issue.HikariCP.issue2169;

import java.sql.Connection;

public class ConnectionCloseHook {

    public void onClose(Connection con) {

    }
}
